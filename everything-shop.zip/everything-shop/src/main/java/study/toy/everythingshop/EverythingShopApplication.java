package study.toy.everythingshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EverythingShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(EverythingShopApplication.class, args);
	}

}
