package study.toy.everythingshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EverythingShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
